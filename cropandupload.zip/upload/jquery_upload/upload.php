<html>
<body>
	<div align="center">
			<img src="" style="float: left; margin-right: 10px;" id="thumbnail" alt="Create Thumbnail" />
			<div style="border:1px #e5e5e5 solid; float:left; position:relative; overflow:hidden; width:px; height:<?php //echo $thumb_height;?>px;">
				<img src="<?php //echo $upload_path.$large_image_name.$_SESSION['user_file_ext'];?>" style="position: relative;" alt="Thumbnail Preview" id="pre"/>
			</div>
			</div>
			<form name="thumbnail" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
				<input type="hidden" name="x1" value="" id="x1" />
				<input type="hidden" name="y1" value="" id="y1" />
				<input type="hidden" name="x2" value="" id="x2" />
				<input type="hidden" name="y2" value="" id="y2" />
				<input type="hidden" name="w" value="" id="w" />
				<input type="hidden" name="h" value="" id="h" />
				<input type="submit" name="upload_thumbnail" value="Save Thumbnail" id="save_thumb" />
			</form>
			
				<form name="photo" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
	Photo <input type="file" name="image" size="30" onchange="readURL(this)"/> <input type="button" name="upload" value="Upload" />
	</form>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" ></script>

<script type="text/javascript">

				 function readURL(input)
				  { 
					  //alert("alert")
					  $.browser = {};
					  $.browser.msie = false;
					    $.browser.version = 0;
					    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
					        $.browser.msie = true;
					        $.browser.version = RegExp.$1;
					    }
					//  var imgurl=document.getElementById('imgurl').value; //alert(imgurl)
				     if (input.files && input.files[0]) {  //alert("alert1")
				     	var iSize = 0;		

				     	
				 	     if($.browser.msie)			
				 	     {			// alert("alert2")
				 	        var objFSO = new ActiveXObject("Scripting.FileSystemObject");			
				 	        var sPath =input.value;			
				 	        var objFile = objFSO.getFile(sPath);			
				 	        var iSize = objFile.size;			
				 	        iSize = iSize/ 1024;			
				 	     } else 
				 	      iSize = (input.files[0].size / 1024);
				 		
				 	   		if ((iSize / 1024)  > 1)
				 	      	{  //alert("alert3")
				 	          iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
				 	          jAlert("File size should be less than 15 MB.");
				 	          $('#thumbnail').attr('src','');
				 	          input.value='';
				 	         return false;
				 	       	}else{  //alert("alert4")
				         var reader = new FileReader();
				         reader.onload = function (e) {  //alert("alert5")
				         $('#thumbnail').attr('src', e.target.result);
				        }
				 	       	}
				         reader.readAsDataURL(input.files[0]);
				        }
				     }
					 
				
function preview(img, selection) { 
	var scaleX =  selection.width; 
	var scaleY =  selection.height; 
	
	$('#pre').css({ 
		width: Math.round(scaleX) + 'px', 
		height: Math.round(scaleY) + 'px',
		marginLeft: '-' + Math.round(scaleX * selection.x1) + 'px', 
		marginTop: '-' + Math.round(scaleY * selection.y1) + 'px' 
	});
	$('#x1').val(selection.x1);
	$('#y1').val(selection.y1);
	$('#x2').val(selection.x2);
	$('#y2').val(selection.y2);
	$('#w').val(selection.width);
	$('#h').val(selection.height);
} 

$(document).ready(function () { 
	$('#save_thumb').click(function() {
		var x1 = $('#x1').val();
		var y1 = $('#y1').val();
		var x2 = $('#x2').val();
		var y2 = $('#y2').val();
		var w = $('#w').val();
		var h = $('#h').val();
		if(x1=="" || y1=="" || x2=="" || y2=="" || w=="" || h==""){
			alert("You must make a selection first");
			return false;
		}else{
			return true;
		}
	});
}); 

$(window).load(function () { 
	$('#thumbnail').imgAreaSelect({ aspectRatio: '1:1', onSelectChange: preview }); 
});

</script>